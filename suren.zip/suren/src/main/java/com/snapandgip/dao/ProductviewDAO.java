package com.snapandgip.dao;

public interface ProductviewDAO {
	public String getallPV();
	public String[] viewallPV(int prod_id);

}
