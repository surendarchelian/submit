package com.snapandgip.dao;

import java.util.List;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.google.gson.Gson;
import com.snapandgip.model.Bill;

@Repository
@Transactional
public class BillDAOImpl implements BillDao {

	@Autowired
	SessionFactory sessionFactory;
	
	public void add(Bill bmpl) {
		
	   Session session=sessionFactory.openSession();
	   Transaction tx=session.getTransaction();
	   tx.begin();
	   session.save(bmpl);
	   
	   
	   tx.commit();
	   session.close();
		
	}
	
	public List getBillingAddress(){
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		List getBillingAddress=session.createQuery("from Bill").list();
		tx.commit();
		session.close();
		return getBillingAddress;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	//	@Autowired
//	SessionFactory sessionFactory;
//	
//	
//	public void add(Bill abmobject) 
//	{
//		
//		Session session=sessionFactory.openSession();
//
//		Transaction tx=session.getTransaction();
//
//		tx.begin();
//		session.save(abmobject);
//
//		tx.commit();
//		//session.flush();
//		session.close();
//		
//
//	}
//
//
//	public List getAllBill() {
//		// TODO Auto-generated method stub
//		Session session=sessionFactory.openSession();
//		Transaction tx=session.getTransaction();
//		tx.begin();
//		List list=session.createQuery("from Category").list();
//		//session.flush();
//		tx.commit();
//		session.close();
//		return list;
//	}
//
//	public void delete(int bill_id) {
//		// TODO Auto-generated method stub
//		
//		Session session=sessionFactory.openSession();
//		Transaction tx=session.getTransaction();
//		tx.begin();
//		Bill c=(Bill)session.get(Bill.class, bill_id);
//		
//	    
//		session.delete(c);
//	    //session.flush();
//	    tx.commit();
//	    session.close();
//	}
//
//
//   public void editBill(Bill ashzonentities){
//	    
//	   	Session session=sessionFactory.openSession();
//		Transaction tx=session.getTransaction();
//		tx.begin();
//		Bill ashobj=(Bill)session.get(Bill.class, ashzonentities.getBill_id());
//		ashobj.setBill_name(ashzonentities.getBill_name());
//		ashobj.setBill_add1(ashzonentities.getBill_add1());
//		ashobj.setBill_add2(ashzonentities.getBill_add2());
//		ashobj.setBill_city(ashzonentities.getBill_city());
//		ashobj.setBill_state(ashzonentities.getBill_state());
//		ashobj.setBill_country(ashzonentities.getBill_country());
//		ashobj.setBill_ZipCode(ashzonentities.getBill_ZipCode());
//		ashobj.setBill_cell(ashzonentities.getBill_cell());
//		session.update(ashobj);
//	    
//	    tx.commit();
//	    
//	   
//	   
//	   
//	   
//   }
//
//
//	public Bill editBill(int bill_id) {
//		// TODO Auto-generated method stub
//		Session session=sessionFactory.openSession();
//		Transaction tx=session.getTransaction();
//		tx.begin();
//		
//		Bill b=(Bill)session.get(Bill.class, bill_id);
//		
//	    
//	    tx.commit();
//	    session.close();
//	
//		return b;
//	}
//


}



