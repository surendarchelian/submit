package com.snapandgip.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.snapandgip.dao.ProductviewDAO;
import com.snapandgip.model.Category;
import com.snapandgip.model.ProductModel;
import com.snapandgip.model.Supplier;
import com.google.gson.Gson;
@Repository
@Transactional
public class ProductviewDAOImpl  implements ProductviewDAO 
{
	
	
		@Autowired
		private SessionFactory sessionFactory;

		
		

		
		public String getallPV() {
			// TODO Auto-generated method stub
			Session session=sessionFactory.openSession();
			Transaction tx=session.getTransaction();
			tx.begin();
			List listpro=session.createQuery("from ProductModel").list();
			Gson gson=new Gson();
			String pv=gson.toJson(listpro);
			
			tx.commit();
			session.close();
			
			return pv;
		}





		public String[] viewallPV(int prod_id) {
			// TODO Auto-generated method stub
			int cat_id,supp_id;
			
			Session session=sessionFactory.openSession();
			Transaction tx=session.getTransaction();
			tx.begin();
			ProductModel c=(ProductModel)session.get(ProductModel.class, prod_id);
		    cat_id=c.getCat_id();
		    supp_id=c.getSupp_id();
		    Category d=(Category)session.get(Category.class, cat_id);
	        Supplier e=(Supplier)session.get(Supplier.class, supp_id);		
		
			Gson gson=new Gson();
			String pd[]=new String[3];
			pd[0]=gson.toJson(c);
			pd[1]=gson.toJson(d);
			pd[2]=gson.toJson(e);
//			session.flush();
			tx.commit();
			session.close();
			return pd;
		}
	}



