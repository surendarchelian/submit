package com.snapandgip.dao;

import java.util.List;

import com.snapandgip.model.User;

public interface UserDAO {
	public void AddUser(User udobj);
	public List getAllUser();
	public void delUserCred(int user_credentialid);
}
