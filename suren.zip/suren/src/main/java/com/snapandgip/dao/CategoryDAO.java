package com.snapandgip.dao;

import java.util.List;

import com.snapandgip.model.Category;




public interface CategoryDAO {


	public void add(Category acmobject);
	public List getAllCategory();
	public void delete(int cat_id);
	public Category editCategory(int cat_id);
	public void editCategory(Category acmobject);
	
}
