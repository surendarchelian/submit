package com.snapandgip.dao;


import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.snapandgip.model.UserCredentials;

import com.snapandgip.model.User;


@Repository
@Transactional
public  class UserDAOimpl implements UserDAO  
{

	@Autowired
	private SessionFactory sessionFactory;
	
	public void AddUser(User udcobj) {
		// TODO Auto-generated method stub
		
		UserCredentials uc=new UserCredentials();
		uc.setUser_name(udcobj.getuser_username());
		uc.setUser_pass(udcobj.getUser_pass());
		
		Session session=sessionFactory.openSession();
		   Transaction tx=session.getTransaction();
		   tx.begin();
		   session.save(udcobj);
		   session.save(uc);
		   
		   tx.commit();
		   session.close();	
				
	}
	public List getAllUser() {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		   Transaction tx=session.getTransaction();
		   tx.begin();
		   List list=session.createQuery("from User").list();
		   
		   
		   tx.commit();
		   session.close();
		
		return list;
	}

	
	public void delUserCred(int user_id) {
		// TODO Auto-generated method stub
		int user_credentialid=user_id-1;
		
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
	     UserCredentials acm=(UserCredentials)session.get(UserCredentials.class, user_credentialid);
		User adm=(User)session.get(User.class, user_id);
		
		session.delete(acm);
		session.delete(adm);
		
		tx.commit();
		session.close();
	}

}
