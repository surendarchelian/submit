package com.snapandgip.dao;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import com.snapandgip.model.ProductModel;
import com.snapandgip.model.Supplier;
import com.snapandgip.model.Category;

import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class ProductDAOImpl implements ProductDAO {
	@Autowired
	private SessionFactory sessionFactory;
	
	
	public void addProduct(ProductModel apmobj) {
		// TODO Auto-generated method stub

		   Session session=sessionFactory.openSession();
		   Transaction tx=session.getTransaction();
		   tx.begin();
		   session.save(apmobj);
		   
		   //session.flush();
		   tx.commit();
		   session.close();	
		
		
	}

	public String[] getCatSell() {
		// TODO Auto-generated method stub
		
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		List listcat=session.createQuery("from Category").getResultList();
		List listsup=session.createQuery("from Supplier").getResultList();
		
		Gson g=new Gson();
		String[] cat=new String[2];
		cat[0]=g.toJson(listcat);
		cat[1]=g.toJson(listsup);
		System.out.print(cat[1]);
	
		//session.flush();	
		
		session.close();
		return cat;
	}

	public void delProduct(int prod_id) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
        ProductModel p=(ProductModel)session.get(ProductModel.class, prod_id);
	    session.delete(p);
	      
	    tx.commit();
	    session.close();
	}

	public ProductModel editProduct(int prod_id) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
        
		ProductModel p=(ProductModel)session.get(ProductModel.class, prod_id);
		
		
	    tx.commit();
	    session.close();
		return p;
	}

	public void editProduct(ProductModel apmobj) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
        ProductModel p=(ProductModel)session.get(ProductModel.class, apmobj.getProd_id());
        p.setProd_name(apmobj.getProd_name());
        p.setProd_desc(apmobj.getProd_desc());
        p.setProd_price(apmobj.getProd_price());
        p.setProd_quantity(apmobj.getProd_quantity());
        
        session.update(p);
        tx.commit();
	    session.close();
		
		
	}


	public List view() {
		Session session=sessionFactory.openSession();
	Transaction tx=session.getTransaction();
	tx.begin();
	
	List listpro=session.createQuery("from ProductModel").getResultList();
		return listpro;
	}

}
