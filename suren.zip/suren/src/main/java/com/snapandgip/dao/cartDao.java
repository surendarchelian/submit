package com.snapandgip.dao;

import java.util.List;

import com.snapandgip.model.Cart;
import com.snapandgip.model.ProductModel;
public interface cartDao {
	public List<Cart> addToCart(int pid, List<Cart> cartinfo, int qty);
	public List<Cart> updateQty(int pid, List<Cart> cartinfo, int qty);
	public List<Cart> deleteFromCart(int pid, List<Cart> cartinfo);
	public String viewCart(List<Cart> cartinfo);
}
