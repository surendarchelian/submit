package com.snapandgip.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.snapandgip.model.Supplier;

@Repository
@Transactional
public class SupplierDAOimpl implements SupplierDAO {

	@Autowired
	SessionFactory sessionFactory;
	
	
	public void add(Supplier acmobject) 
	{
		
		System.out.println("1");
		Session session=sessionFactory.openSession();
		System.out.println("2");
		Transaction tx=session.getTransaction();
		System.out.println("3");
		tx.begin();
		System.out.println("4");
		session.save(acmobject);
		System.out.println("5");
		tx.commit();
		System.out.println("6");
		//session.flush();
		System.out.println("7");
		session.close();
		

	}


	public List getAllSupplier() {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		List list=session.createQuery("from Supplier").list();
		//session.flush();
		tx.commit();
		session.close();
		return list;
	}

	public void delete(int supplier_id) {
		// TODO Auto-generated method stub
		
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		Supplier c=(Supplier)session.get(Supplier.class, supplier_id);
		
	    session.delete(c);
	    //session.flush();
	    tx.commit();
	    session.close();
	}


   public void editSupplier(Supplier ashzonentities){
	    
	   	Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		Supplier ashobj=(Supplier)session.get(Supplier.class, ashzonentities.getsupplier_id());
		ashobj.setsupplier_name(ashzonentities.getsupplier_name());
		ashobj.setsupplier_address(ashzonentities.getsupplier_address());
		ashobj.setsupplier_emailid(ashzonentities.getsupplier_emailid());
		session.update(ashobj);
	    
	    tx.commit();
	    
	   
	   
	   
	   
   }


	public Supplier editSupplier(int supplier_id) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		
		Supplier c=(Supplier)session.get(Supplier.class, supplier_id);
		
	    
	    tx.commit();
	    session.close();
	
		return c;
	}
}
