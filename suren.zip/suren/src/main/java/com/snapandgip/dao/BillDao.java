package com.snapandgip.dao;

import java.util.ArrayList;
import java.util.List;


import com.snapandgip.model.Bill;

public interface BillDao {
	
	
	
	public void add(Bill bmpl);
	
	public List getBillingAddress();
	
	
	
	
	
	
//	public void add(Bill abmobject);
//	public List getAllBill();
//	public void delete(int bill_id);
//	public Bill editBill(int bill_id);
//	public void editBill(Bill abmobject);
}
