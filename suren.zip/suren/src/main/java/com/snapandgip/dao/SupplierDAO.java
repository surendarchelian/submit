package com.snapandgip.dao;

import java.util.List;

import com.snapandgip.model.Supplier;

public interface SupplierDAO {
	public void add(Supplier acmobject);
	public List getAllSupplier();
	public void delete(int supplier_id);
	public Supplier editSupplier(int supplier_id);
	public void editSupplier(Supplier acmobject);

}
