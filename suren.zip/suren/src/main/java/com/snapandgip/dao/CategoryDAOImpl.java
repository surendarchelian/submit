package com.snapandgip.dao;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.snapandgip.model.Category;

@Repository
@Transactional
public class CategoryDAOImpl implements CategoryDAO 
{
	@Autowired
	SessionFactory sessionFactory;
	
	
	public void add(Category acmobject) 
	{
		
		Session session=sessionFactory.openSession();

		Transaction tx=session.getTransaction();

		tx.begin();
		session.save(acmobject);

		tx.commit();
		//session.flush();
		session.close();
		

	}


	public List getAllCategory() {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		List list=session.createQuery("from Category").list();
		//session.flush();
		tx.commit();
		session.close();
		return list;
	}

	public void delete(int prod_id) {
		// TODO Auto-generated method stub
		
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		Category c=(Category)session.get(Category.class, prod_id);
		
	    session.delete(c);
	    //session.flush();
	    tx.commit();
	    session.close();
	}


   public void editCategory(Category ashzonentities){
	    
	   	Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		Category ashobj=(Category)session.get(Category.class, ashzonentities.getProd_id());
		ashobj.setProd_name(ashzonentities.getProd_name());
		ashobj.setProd_desc(ashzonentities.getProd_desc());
		session.update(ashobj);
	    
	    tx.commit();
	    
	   
	   
	   
	   
   }


	public Category editCategory(int prod_id) {
		// TODO Auto-generated method stub
		Session session=sessionFactory.openSession();
		Transaction tx=session.getTransaction();
		tx.begin();
		
		Category c=(Category)session.get(Category.class, prod_id);
		
	    
	    tx.commit();
	    session.close();
	
		return c;
	}
}
