package com.snapandgip.dao;

import java.util.List;

import com.snapandgip.model.ProductModel;
public interface ProductDAO {

	public void addProduct(ProductModel apmobj);
	public String[] getCatSell();
	public void delProduct(int prod_id);
	public ProductModel editProduct(int prod_id);
	public void editProduct(ProductModel apmobj);
	public List view();
	
}
