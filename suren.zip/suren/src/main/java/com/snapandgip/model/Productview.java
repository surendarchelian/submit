package com.snapandgip.model;

public class Productview {

}
