package com.snapandgip.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;

import org.springframework.web.multipart.MultipartFile;
@Entity
public class User {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="user_id")
	private int user_id;
	@Column(name="user_name")
	private String user_name;
	@Column(name="user_username")
	private String user_username;
	@Column(name="user_email")
	private String user_email;
	@Column(name="user_address")
	private String user_address;
	@Column(name="user_mobilenumber")
	private String user_mobilenumber;
	@Transient
	private String user_pass;
	
	
	
	
	public String getUser_address() {
		return user_address;
	}
	public void setUser_address(String user_address) {
		this.user_address = user_address;
	}
	public String getUser_pass() {
		return user_pass;
	}
	public void setUser_pass(String user_pass) {
		this.user_pass = user_pass;
	}
	public int getuser_id() {
		return user_id;
	}
	public void setuser_id(int user_id) {
		this.user_id = user_id;
	}
	public String getuser_name() {
		return user_name;
	}
	public void setuser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getuser_username() {
		return user_username;
	}
	public void setuser_username(String user_username) {
		this.user_username = user_username;
	}
	public String getuser_email() {
	return user_email;
	}
	public void setuser_email(String user_email) {
		this.user_email = user_email;
	
}
	public void setuser_mobilenumber(String user_mobilenumber) {
		this.user_mobilenumber = user_mobilenumber;
	
}
	
	
}