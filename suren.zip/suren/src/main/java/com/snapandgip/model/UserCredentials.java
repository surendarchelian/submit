package com.snapandgip.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.web.multipart.MultipartFile;

import javax.persistence.Entity;

@Entity
public class UserCredentials {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)

	@Column(name="user_credentialid")
	private int user_credentialid;
	
	@Column(name="user_credentialname")
	private String user_name;
	
	@Column(name="user_credentialpassword")
	private String user_pass;
	
	@Column(name="user_credentialrole")
	private String role_user="ROLE_USER";
	
	@Column(name="user_credentialstatus")
	boolean status=true;

	public int getUser_credentialid() {
		return user_credentialid;
	}

	public void setUser_credentialid(int user_credentialid) {
		this.user_credentialid = user_credentialid;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	

	

	public String getUser_pass() {
		return user_pass;
	}

	public void setUser_pass(String user_pass) {
		this.user_pass = user_pass;
	}

	public String getRole_user() {
		return role_user;
	}

	public void setRole_user(String role_user) {
		this.role_user = role_user;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}
	
	
}


