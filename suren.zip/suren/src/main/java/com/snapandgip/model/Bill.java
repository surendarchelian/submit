package com.snapandgip.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


public class Bill {
	private String bill_name;
	
	private String bill_add1;

	private String bill_add2;
	
	private String bill_city;
	
	private String bill_state;
	
	private String bill_country;
	
	private String bill_ZipCode;
	
	private String bill_cell;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//	
//	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
//	@Column(name="bill_id")
//	private int bill_id;
//	@Column(name="bill_name")
//	private String bill_name;
//	@Column(name="bill_add1")
//	private String bill_add1;
//	@Column(name="bill_add2")
//	private String bill_add2;
//	@Column(name="bill_city")
//	private String bill_city;
//	@Column(name="bill_state")
//	private String bill_state;
//	@Column(name="bill_country")
//	private String bill_country;
//	@Column(name="bill_ZipCode")
//	private String bill_ZipCode;
//	@Column(name="bill_cell")
//	private String bill_cell;
//	
//
//	public int getBill_id() {
//		return bill_id;
//	}
//
//	public void setBill_id(int bill_id) {
//		this.bill_id = bill_id;
//	}

	public String getBill_name() {
		return bill_name;
	}

	public void setBill_name(String bill_name) {
		this.bill_name = bill_name;
	}

	public String getBill_add1() {
		return bill_add1;
	}

	public void setBill_add1(String bill_add1) {
		this.bill_add1 = bill_add1;
	}	
	public String getBill_add2() {
		return bill_add2;
	}

	public void setBill_add2(String bill_add2) {
		this.bill_add2 = bill_add2;
	}

	public String getBill_city() {
		return bill_city;
	}

	public void setBill_city(String bill_city) {
		this.bill_city = bill_city;
	}

	public String getBill_state() {
		return bill_state;
	}

	public void setBill_state(String bill_state) {
		this.bill_state = bill_state;
	}

	public String getBill_country() {
		return bill_country;
	}

	public void setBill_country(String bill_country) {
		this.bill_country = bill_country;
	}

	public String getBill_ZipCode() {
		return bill_ZipCode;
	}

	public void setBill_ZipCode(String bill_ZipCode) {
		this.bill_ZipCode = bill_ZipCode;
	}

	public String getBill_cell() {
		return bill_cell;
	}

	public void setBill_cell(String bill_cell) {
		this.bill_cell = bill_cell;
	}

	


}
