package com.snapandgip.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;

import org.springframework.web.multipart.MultipartFile;

@Entity
public class ProductModel {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="prod_id")
	private int prod_id;
	@Column(name="prod_name")
	private String prod_name;
	@Column(name="prod_desc")
	private String prod_desc;
	@Column(name="prod_price")
	private long prod_price;
	@Column(name="prod_quantity")
	private int prod_quantity;
    @Column(name="cat_id") 
	private int cat_id;
    @Column(name="supp_id")
	private int supp_id;

	@Transient
	private MultipartFile prod_image;
	
	
	public MultipartFile getProd_image() {
		
		return prod_image;
	}
	public void setProd_image(MultipartFile prod_image) {
		this.prod_image = prod_image;
	}


	public int getProd_id() {
		return prod_id;
	}
	public void setProd_id(int prod_id) {
		this.prod_id = prod_id;
	}
	public String getProd_name() {
		return prod_name;
	}
	public void setProd_name(String prod_name) {
		this.prod_name = prod_name;
	}
	public String getProd_desc() {
		return prod_desc;
	}
	public void setProd_desc(String prod_desc) {
		this.prod_desc = prod_desc;
	}
	public long getProd_price() {
		return prod_price;
	}
	public void setProd_price(long prod_price) {
		this.prod_price = prod_price;
	}
	public int getProd_quantity() {
		return prod_quantity;
	}
	public void setProd_quantity(int prod_quantity) {
		this.prod_quantity = prod_quantity;
	}
	public int getCat_id() {
		return cat_id;
	}
	public void setCat_id(int cat_id) {
		this.cat_id = cat_id;
	}
	public int getSupp_id() {
		return supp_id;
	}
	public void setSupp_id(int supp_id) {
		this.supp_id = supp_id;
	}
	

}
