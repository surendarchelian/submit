package com.snapandgip.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Category{
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
@Column(name="prod_id")
private int prod_id;
@Column(name="prod_name")
private String prod_name;
@Column(name="prod_desc")
private String prod_desc;


public int getProd_id() {
	return prod_id;
}

public void setProd_id(int prod_id) {
	this.prod_id = prod_id;
}

public String getProd_name() {
	return prod_name;
}

public void setProd_name(String prod_name) {
	this.prod_name = prod_name;
}

public String getProd_desc() {
	return prod_desc;
}

public void setProd_desc(String prod_desc) {
	this.prod_desc = prod_desc;
}	

}



