package com.snapandgip.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Supplier {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="supplier_id")
	private int supplier_id;
	@Column(name="supplier_name")
	private String supplier_name;
	@Column(name="supplier_address")
	private String supplier_address;
	@Column(name="supplier_emailid")
	private String supplier_emailid;


	public int getsupplier_id() {
		return supplier_id;
	}

	public void setsupplier_id(int supplier_id) {
		this.supplier_id = supplier_id;
	}

	public String getsupplier_name() {
		return supplier_name;
	}

	public void setsupplier_name(String supplier_name) {
		this.supplier_name = supplier_name;
	}

	public String getsupplier_address() {
		return supplier_address;
	}

	public void setsupplier_address(String supplier_address) {
		this.supplier_address = supplier_address;
	}
	public String getsupplier_emailid() {
		return supplier_emailid;
	}

	public void setsupplier_emailid(String supplier_emailid) {
		this.supplier_emailid = supplier_emailid;
	}

	}


