package com.snapandgip.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.snapandgip.model.Category;
import com.google.gson.Gson;
import com.snapandgip.dao.CategoryDAO;
import com.snapandgip.model.Category;
//import org.springframework.web.servlet.ModelAndView;
@Controller
public class CategoryController {
		
	
	  @Autowired
	  CategoryDAO cdao;
		
	  public String getdata(){
	  		
	  		ArrayList list=(ArrayList)cdao.getAllCategory();
	  		Gson gson=new Gson();
	  		String jsonInString = gson.toJson(list);
			
	  		return jsonInString;
	  	}	
	  
	  
	  
		@RequestMapping(value="/sun.mancat")
		public ModelAndView goToManageCategory(Model m)
		{
			ModelAndView mv=new ModelAndView("addisplay","Category", new Category());
			return mv;
			
			
	}
		
		
		@RequestMapping(value="/sun.mancat",method=RequestMethod.POST)
		public ModelAndView addCategory(Category acmobject,Model m){
		
			
		cdao.add(acmobject);
		m.addAttribute("list",getdata());
		
		System.out.println("no ooooo 1");
		ModelAndView mv=new ModelAndView("catsucess","acmobject",new Category());
		System.out.println("no ooooo 2");
		return mv;
		  
		}
		@RequestMapping(value="/sun.viewcat")
		public ModelAndView viewCategory(Category acmobject,Model m){
			
			m.addAttribute("list",getdata());
			ModelAndView mv=new ModelAndView("catsucess","acmobject",new Category());
			
			return mv;
		}
		
		@RequestMapping(value="/sun.dellmancat")
		public ModelAndView dellCategory(@RequestParam("id")int prod_id,Model m){
			
			cdao.delete(prod_id);
			m.addAttribute("list",getdata());
			ModelAndView mv=new ModelAndView("catsucess","acmobject",new Category());
			return mv;
			
			
		}
		
		@RequestMapping(value="/sun.editcath2",method=RequestMethod.POST)
		public ModelAndView editCategory(Category acmobject,Model m){
			
					
			cdao.editCategory(acmobject);
					
			m.addAttribute("list",getdata());
			
			
			ModelAndView mv=new ModelAndView("catsucess","acmobject",new Category());

			return mv;

			
			
		}
		
		
		
		@RequestMapping(value="/sun.editmancat")
		public ModelAndView editCategory(@RequestParam("id")int prod_id,Model m){
			
			System.out.println("im here....!!");
			Category obj=cdao.editCategory(prod_id);
			
			Gson gson=new Gson();
	  		String jsonInString = gson.toJson(obj);
			m.addAttribute("editval",jsonInString);
			ModelAndView mv=new ModelAndView("editcat","acmobject",new Category());
			return mv;
		}
		@RequestMapping("/manage")
		public String gotolog()
		{
			return "catin";
		}
		@RequestMapping("/managev")
		public ModelAndView gotol(Model m)
		{
			m.addAttribute("list",getdata());
			ModelAndView mv=new ModelAndView("catsucess","acmobject",new Category());
			return mv;
		}
	}



