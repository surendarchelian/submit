package com.snapandgip.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.snapandgip.dao.ProductDAO;
import com.snapandgip.dao.ProductviewDAO;
@Controller
public class ProductviewControler {

	@Autowired
	private ProductDAO apdo;
	
	private String getdata()
	{
		List prodet=apdo.view();
		Gson gson=new Gson();
		String bond=gson.toJson(prodet);
		
		return bond;
	}
	
	
	@RequestMapping("/snap.pro")
	public ModelAndView getpv(Model m){
		
		m.addAttribute("prodlist",getdata());
		ModelAndView mv=new ModelAndView("product");
		return mv;
	}
	
	
}
