package com.snapandgip.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.snapandgip.dao.BillDAOImpl;
import com.snapandgip.dao.BillDao;
import com.snapandgip.model.Bill;

import javax.servlet.http.HttpServletResponse;

@Controller
public class BillController {
	  @Autowired
	  BillDAOImpl bdao;
	  	@Autowired
	  	private SessionFactory sessionFactory;
	  public String getdata(){
		  
		  
			 ArrayList list=(ArrayList) bdao.getBillingAddress();
			 Gson gson= new Gson();
			 String jsonInString=gson.toJson(list);
			 return jsonInString;
		 }
		 
		
		@RequestMapping(value="/snap.manbill")

		public ModelAndView addBilling(Model m){
			
			
			ModelAndView mv=new ModelAndView("card","billingaddress",new Bill());
			
			
			return mv;
		}
		
		

		
	@RequestMapping(value="/bill.order")
	public ModelAndView add(@ModelAttribute Bill bmpl, HttpSession session){
		
		
		
		session.setAttribute("order",bmpl);
		ModelAndView mv=new ModelAndView("successorder");
		
		return mv;
		
	}
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
//	  public String getdata(){
//	  		
//	  		ArrayList list=(ArrayList)bdao.getAllBill();
//	  		Gson gson=new Gson();
//	  		String jsonInString = gson.toJson(list);
//			
//	  		return jsonInString;
//	  	}	
//	  
//	  
//	  
//		@RequestMapping(value="./snap.manbill")
//		public ModelAndView goToManageBill(Model m)
//		{
//			ModelAndView mv=new ModelAndView("address","Bill", new Bill());
//			return mv;
//			
//			
//	}
//		
//		
//		@RequestMapping(value="/snap.manbill",method=RequestMethod.POST)
//		public ModelAndView addCategory(@ModelAttribute Bill abmobject,Model m){
//		
//			
//		bdao.add(abmobject);
//		m.addAttribute("list",getdata());
//		
//		System.out.println("no ooooo 1");
//		ModelAndView mv=new ModelAndView("card","abmobject",new Bill());
//		System.out.println("no ooooo 2");
//		return mv;
		  
//		}
//		@RequestMapping(value="/snap.viewbill")
//		public ModelAndView viewBill(Bill abmobject,Model m){
//			
//			m.addAttribute("list",getdata());
//			ModelAndView mv=new ModelAndView("Bill","abmobject",new Bill());
//			
//			return mv;
//		}
//		
//		@RequestMapping(value="/snap.dellbill")
//		public ModelAndView dellBill(@RequestParam("id")int bill_id,Model m){
//			
//			bdao.delete(bill_id);
//			m.addAttribute("list",getdata());
//			ModelAndView mv=new ModelAndView("Bill","abmobject",new Bill());
//			return mv;
//			
//			
//		}
//		
//		@RequestMapping(value="/snap.editbill2",method=RequestMethod.POST)
//		public ModelAndView editBill(Bill abmobject,Model m){
//			
//					
//			bdao.editBill(abmobject);
//					
//			m.addAttribute("list",getdata());
//			
//			
//			ModelAndView mv=new ModelAndView("Bill","abmobject",new Bill());
//
//			return mv;
//
//			
//			
//		}
//		
//		
//		
//		@RequestMapping(value="/sun.editmancat")
//		public ModelAndView editCategory(@RequestParam("id")int bill_id,Model m){
//			
//			System.out.println("im here....!!");
//			Bill obj=bdao.editBill(bill_id);
//			
//			Gson gson=new Gson();
//	  		String jsonInString = gson.toJson(obj);
//			m.addAttribute("editval",jsonInString);
//			ModelAndView mv=new ModelAndView("editcat","abmobject",new Bill());
//			return mv;
//		}
//		@RequestMapping("/manage")
//		public String gotolog()
//		{
//			return "catin";
//		}
//		@RequestMapping("/managev")
//		public ModelAndView gotol(Model m)
//		{
//			m.addAttribute("list",getdata());
//			ModelAndView mv=new ModelAndView("catsucess","abmobject",new Bill());
//			return mv;
//		}
		


}
