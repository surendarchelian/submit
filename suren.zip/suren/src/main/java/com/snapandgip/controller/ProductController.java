package com.snapandgip.controller;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.google.gson.Gson;
import com.snapandgip.dao.ProductDAO;
import com.snapandgip.model.Category;
import com.snapandgip.model.ProductModel;
import com.snapandgip.model.Supplier;

@Controller
public class ProductController {
	@Autowired
	private ProductDAO apdo;
	
	private String getdata()
	{
		List prodet=apdo.view();
		Gson gson=new Gson();
		String bond=gson.toJson(prodet);
		
		return bond;
	}
	
	
	@RequestMapping(value="/suren.manpro",method=RequestMethod.GET)
	public ModelAndView manProduct(Model m){
		
		ModelAndView mv=new ModelAndView("PRODUCTADD","product",new ProductModel());
		
		return mv;
	}
	
	@RequestMapping(value="/suren.addproh2",method=RequestMethod.POST)
	public ModelAndView addProduct(@ModelAttribute("product") ProductModel apmobj ,HttpServletRequest request, RedirectAttributes attributes, Model m) throws InterruptedException{
		System.out.println("inside /suren.addproh2");
		System.out.println("Controller");
		apdo.addProduct(apmobj);
		
		String path="C:\\Users\\suren\\workspace\\suren\\src\\main\\webapp\\resources\\images\\";
		System.out.println("File not uploaded error....1");
		path=path+String.valueOf(apmobj.getProd_id()+".jpg");
		System.out.println("File not uploaded error....2");
		File f=new File(path);
		System.out.println("File not uploaded error....3");
		
		MultipartFile fileloc=apmobj.getProd_image();
		
		if(!fileloc.isEmpty())	
		{
			try{
				byte[] bytes=fileloc.getBytes();
				FileOutputStream fos=new FileOutputStream(f);
				BufferedOutputStream bs=new BufferedOutputStream(fos);
				bs.write(bytes);
      			bs.close();
      			System.out.println("File Uploaded Successfully");
     			
				
			}
			
			catch(Exception e){
				
				System.out.println("File not uploaded error....");
			}
		}
		Thread.sleep(1000);
		
		m.addAttribute("list", getdata());
		ModelAndView mv=new ModelAndView("PRODUCTVIEW","apmobject",new ProductModel());
		
		return mv;
	}

	@RequestMapping(value="/suren.viewProduct")
	public ModelAndView viewProduct(ProductModel apmobject,Model m){
		
		m.addAttribute("list",getdata());
		ModelAndView mv=new ModelAndView("PRODUCTVIEW","apmobject",new ProductModel());
		
		return mv;
	}
	
	@RequestMapping(value="/suren.delProduct")
	public ModelAndView delProduct(@RequestParam("id")int prod_id,Model m){
		
		System.out.println("laskfl");
		apdo.delProduct(prod_id);
		System.out.println("laskfl");
		m.addAttribute("list",getdata());
		ModelAndView mv=new ModelAndView("PRODUCTVIEW","apmobject",new ProductModel());
		return mv;
		
		
	}
	
	@RequestMapping(value="/sun.editProduct2",method=RequestMethod.POST)
	public ModelAndView editProduct(ProductModel apmobject,Model m){
		
		System.out.println("laskfl");		
		apdo.editProduct(apmobject);
		System.out.println("laskfl");
		m.addAttribute("list",getdata());
		System.out.println("laskfl");
		
		ModelAndView mv=new ModelAndView("PRODUCTVIEW","apmobject",new ProductModel());

		return mv;

		
		
	}
	
	
	
	@RequestMapping(value="/suren.editmanProduct")
	public ModelAndView editProduct(@RequestParam("id")int prod_id,Model m){
		
		System.out.println("im here....!!");
		ProductModel obj=apdo.editProduct(prod_id);
		Gson gson=new Gson();
  		String jsonInString = gson.toJson(obj);
		m.addAttribute("editval",jsonInString);
		ModelAndView mv=new ModelAndView("editproduct","apmobject",new ProductModel());
		return mv;
	}
	
	



	@RequestMapping("/pro")
	public String gotolog(Model m)
	{
		System.out.println("inside /pro");
		String[] catselldetails=apdo.getCatSell();
		m.addAttribute("product", new ProductModel());
		m.addAttribute("catlist",catselldetails[0]);
		m.addAttribute("suplist",catselldetails[1]);
		return "PRODUCTADD";
	}
	
	@RequestMapping("/prov")
	public ModelAndView gotol(Model m){
		
		m.addAttribute("list",getdata());
		ModelAndView mv=new ModelAndView("PRODUCTVIEW","apmobject",new ProductModel());
		return mv;
	}
}
