package com.snapandgip.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.snapandgip.dao.SupplierDAO;
import com.snapandgip.model.Supplier;
@Controller
public class SupplierController {
	@RequestMapping("/supply")
	public String gotosupply()
	{
		return "supplyin";
	}

	@RequestMapping("/supplyv")
	public ModelAndView gotosupp(Model m)
	{
		m.addAttribute("list",getdata());
		
		
		ModelAndView mv=new ModelAndView("supplysuccess","acmobject",new Supplier());

		return mv;
	}

	 @Autowired
	  SupplierDAO cdao;
		
	  public String getdata(){
	  		
	  		ArrayList list=(ArrayList)cdao.getAllSupplier();
	  		Gson gson=new Gson();
	  		String jsonInString = gson.toJson(list);
			
	  		return jsonInString;
	  	}	
	  
	  
	  
		@RequestMapping(value="/moon.mansupply")
		public ModelAndView goToManageCategory(Model m)
		{
			ModelAndView mv=new ModelAndView("addisplay","Supplier", new Supplier());
			return mv;
			
			
	}
		
		
		@RequestMapping(value="/moon.mansupply",method=RequestMethod.POST)
		public ModelAndView addSupplier(Supplier acmobject,Model m){
		
			
		cdao.add(acmobject);
		m.addAttribute("list",getdata());
		
		System.out.println("no ooooo 1");
		ModelAndView mv=new ModelAndView("supplysuccess","acmobject",new Supplier());
		System.out.println("no ooooo 2");
		return mv;
		  
		}
		@RequestMapping(value="/moon.viewsupply")
		public ModelAndView viewSupplier(Supplier acmobject,Model m){
			
			m.addAttribute("list",getdata());
			ModelAndView mv=new ModelAndView("supplysuccess","acmobject",new Supplier());
			
			return mv;
		}
		
		@RequestMapping(value="/moon.dellmansupply")
		public ModelAndView dellSupplier(@RequestParam("id")int supplier_id,Model m){
			
			cdao.delete(supplier_id);
			m.addAttribute("list",getdata());
			ModelAndView mv=new ModelAndView("supplysuccess","acmobject",new Supplier());
			return mv;
			
			
		}
		
		@RequestMapping(value="/moon.editcath2",method=RequestMethod.POST)
		public ModelAndView editSupplier(Supplier acmobject,Model m){
			
					
			cdao.editSupplier(acmobject);
					
			m.addAttribute("list",getdata());
			
			
			ModelAndView mv=new ModelAndView("supplysuccess","acmobject",new Supplier());

			return mv;

			
			
		}
		
		
		
		@RequestMapping(value="/moon.editmansupply")
		public ModelAndView editSupplier(@RequestParam("id")String supp_id,Model m){
			
			
			int supplier_id=Integer.parseInt(supp_id);
			
			System.out.println("im here....!!");
			Supplier obj=cdao.editSupplier(supplier_id);
			
			Gson gson=new Gson();
	  		String jsonInString = gson.toJson(obj);
			m.addAttribute("editval",jsonInString);
			ModelAndView mv=new ModelAndView("editsupply","acmobject",new Supplier());
			return mv;
		}
		
		
}
