package com.snapandgip.controller;

import java.util.Collection;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.snapandgip.dao.UserDAOimpl;
import com.snapandgip.model.User;

@Controller
public class LoginController 
{
	
@Autowired
UserDAOimpl user;

@SuppressWarnings("unchecked")

@RequestMapping(value="/login_session_attributes",method=RequestMethod.POST)
public String logsucc(Model m){
	
	Collection<GrantedAuthority> authorities = (Collection<GrantedAuthority>) SecurityContextHolder.getContext().getAuthentication().getAuthorities();
	String urlmapping="";
	String role="ROLE_USER";
	for (GrantedAuthority authority : authorities) 
	{
		System.out.println("inside");
		if (authority.getAuthority().equals("ROLE_ADMIN")) 
	     {
	    	// session.setAttribute("Administrator", "true");
	    	 urlmapping="/admin";
		
	    }
		else
	     {
			
			
			System.out.println("inside useeerr");
	    	// session.setAttribute("UserLoggedIn", "true");
			urlmapping="/snap.pro";
	    	 //session.setAttribute("cartsize",cartDAO.cartsize((int)session.getAttribute("userId")));
	     }
	     
	}
	return "redirect:"+urlmapping;
}



//	@RequestMapping(value = "/login_session_attributes")
//	public String login_session_attributes(HttpSession session,Model model) {
//		
//
//		Collection<GrantedAuthority> authorities = (Collection<GrantedAuthority>) SecurityContextHolder.getContext().getAuthentication().getAuthorities();
//		String page="";
//		String role="ROLE_USER";
//		for (GrantedAuthority authority : authorities) 
//		{
//		  
//		     if (authority.getAuthority().equals(role)) 
//		     {
//		    	 session.setAttribute("UserLoggedIn", "true");
//			 page="/snap.pro";
//		    	 //session.setAttribute("cartsize",cartDAO.cartsize((int)session.getAttribute("userId")));
//		     }
//		     else 
//		     {
//		    	 session.setAttribute("Administrator", "true");
//			
//		    }
//		}
//		return page;
//	}
//@RequestMapping("/logout")
//public String gotologo()
//{
//	return "Login";
//}

@RequestMapping(value="/logout", method = RequestMethod.GET)
public String logoutPage (HttpServletRequest request, HttpServletResponse response) {
    Authentication auth = SecurityContextHolder.getContext().getAuthentication();
    if (auth != null){    
        new SecurityContextLogoutHandler().logout(request, response, auth);
    }
    return "Login";//You can redirect wherever you want, but generally it's a good practice to show login screen again.
}

}



