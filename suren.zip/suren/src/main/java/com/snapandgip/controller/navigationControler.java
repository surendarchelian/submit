package com.snapandgip.controller;


import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.snapandgip.dao.ProductDAO;
import com.snapandgip.dao.ProductviewDAO;

@Controller
public class navigationControler
{
	@Autowired
	private ProductviewDAO pv;
	@Autowired
	private ProductDAO apdo;
	
	private String getprod()
	{
		List prodet=apdo.view();
		Gson gson=new Gson();
		String bond=gson.toJson(prodet);
		
		return bond;
	}
	
	@RequestMapping("/log")
	public String gotolog()
	{
		return "Login";
	}
	
	
	
	@RequestMapping("/admin")
	public String gotoadmin()
	{
		
		
		return "admin";
	}
	
	

	@RequestMapping("/perform_login")
	public String gotoadmn()
	{
		
		
		return "admin";
	}
	
	@RequestMapping("/add.add")
	public String gotoadd()
	{
		return "success";
	}
	
	@RequestMapping("/suren")
	public String gotoabout()
	{
		return "about";
	}
	@RequestMapping("/RAJ")
	public String gotoreg()
	{
		return "register";
	}
	@RequestMapping("/con")
	public String gotocon()
	{
		return "contact";
	}
	@RequestMapping("/produc")
	public String gotopro()
	{
		return "product";
	}
//	@RequestMapping("/pro1")
//	public ModelAndView getdata() {
//
//	
//       List<String> list=getList();
//		
//		ModelAndView model = new ModelAndView("product");
//		model.addObject("lists", list);
//
//		return model;
//
//	}
	@RequestMapping("/")
	public ModelAndView homepage() {
		
		
		ModelAndView model = new ModelAndView();
		model.addObject("prodlist", getprod());
		model.setViewName("index");
		return model;
	}
	
	}
