package com.snapandgip.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.Gson;
import com.snapandgip.dao.UserDAO;
import com.snapandgip.model.User;
@Controller
public class UserController {
	  @Autowired
	 private UserDAO sdao;
		
	  public String getUserCredential(){
			List list=(sdao).getAllUser();
			Gson gson=new Gson();
			String jsonInString=gson.toJson(list);
			System.out.println(jsonInString);
			return jsonInString;
			
		}
	  @RequestMapping(value="/sun.manuser")
		public ModelAndView gotouserinfo (@ModelAttribute User udobj, Model m)
		{sdao.AddUser(udobj);
		ModelAndView mv=new ModelAndView();
		mv.setViewName("redirect:/");
		return mv;
		}
		
		@RequestMapping(value="/sun.userview")
		public ModelAndView regusercred(User udobj, Model m){
			
	    m.addAttribute("list", getUserCredential());
		ModelAndView mv=new ModelAndView("Usersuccess","udobj", new User());
		return mv;
		}
//		@RequestMapping(value="/sun.dellusercred")
//		public ModelAndView dellUserCred(@RequestParam("id")int usercred_id,Model m){
//			
//			sdao.delUserCred(usercred_id);
//			m.addAttribute("userdetailslist",getUserCredential());
//			ModelAndView mv=new ModelAndView("userdetailsview");
//			return mv;
//		}
	
	}
